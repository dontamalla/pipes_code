from django.http import HttpResponse

from rest_framework.decorators import api_view
from rest_framework.response import Response


@api_view(['GET', 'POST'])
def healthz(request):
    return Response(data={"status": "ok"})

pipes = []
@api_view(['GET', 'POST', 'DELETE'])
def pipe_information(request, pipe_id):
    if request.method == "GET":
        lis = []
        for i in pipes:
            if i[pipe_id] == pipe_id:
                return response(status = 200, data = pipes[i])
        return response(status = 404)

    elif request.method == "DELETE":
        for d in pipes:
            if d[pipe_id] == pipe_id:
                del pipes[d]
                return response(status = 200)
        return response(status = 404)
    elif request.method == "POST":
        pipe_name = request.data.get("name")
        pipe_size = request.data.get("size")
        pipe_prize = request.data.get("price")
        pipe_batch = request.data.get("batch")
        d={}
        for p in pipes:
            d["id"] = pipe_id
            d["name"] = pipe_name
            d["size"] = pipe_size
            d["price"] = pipe_prize
            d["batch"] = pipe_batch
            pipes.append(d)
            return response(status = 200)
        return response(status = 401)

@api_view(['GET'])
def total_pipes(request):
    if request.method == "GET":
        pipe_dict = {}
        pipe_dict["total_pipes"] = pipes
        return response(status = 200, data = pipe_dict)